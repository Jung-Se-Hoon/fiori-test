sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("zc518.cds0002.fioricds02.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  