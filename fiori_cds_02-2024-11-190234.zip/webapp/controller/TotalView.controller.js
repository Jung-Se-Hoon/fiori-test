sap.ui.define([
    "sap/ui/core/mvc/Controller"
],
function (Controller) {
    "use strict";

    return Controller.extend("zc518.cds0002.fioricds02.controller.TotalView", {
        onInit: function () {

        }
    });
});
