/* global QUnit */

sap.ui.require(["zc518/cds0002/fioricds02/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
