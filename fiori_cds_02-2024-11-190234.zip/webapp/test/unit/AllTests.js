sap.ui.define([
	"zc518cds0002/fiori_cds_02/test/unit/controller/TotalView.controller"
], function () {
	"use strict";
});
